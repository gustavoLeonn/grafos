(ns conversor.core
  (:require [clojure.tools.cli	:refer	[parse-opts]]
            [clj-http.client :as http-client]
            [cheshire.core	:refer	[parse-string]])
  (:gen-class))

(def opcoes-do-programa 
  [["-d" "--de moeda	base" "moeda	base	para	conversão"
    :default "eur"]
   ["-p" "--para moeda de interesse" 
   "moeda	a	qual	queremos	saber	o	valor"]]
)

(def chave (System/getenv "CHAVE_API"))

(def api-url "https://api.freecurrencyapi.com/v1/latest?apikey=fca_live_CmEyW0HM2pNR5EtloKYWIjSIBBSUgPxot6az1oVe")

(defn parametrizar-moedas [de para]
(str de "_" para)
)

(defn obter-cotacao [de para]
  (-> (:body
        (http-client/get
          "https://api.freecurrencyapi.com/v1/latest"
          {:query-params {"apikey" chave
                          "base_currency" (.toUpperCase de)
                          "currencies" (.toUpperCase para)}}))
      parse-string
      (get-in ["data" (.toUpperCase para)])))

(defn-	formatar	[cotacao	de	para]
		(str "1 "	de " equivale a "	cotacao	" em "para))

(defn -main
  [& args]
  (let [{:keys [de para]}
        (:options (parse-opts args opcoes-do-programa))]
    (-> (obter-cotacao de para)
        (formatar de para)
        (println))))