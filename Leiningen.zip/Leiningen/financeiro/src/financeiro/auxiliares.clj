(ns	financeiro.auxiliares
		(:require	[ring.adapter.jetty	:refer	[run-jetty]]
												[financeiro.handler	:refer	[app]]
												[cheshire.core	:as	json]
												[clj-http.client	:as	http]))
;;	...
;;	as	novas	funções
(defn	conteudo-como-json	[transacao]
		{:content-type	:json
			:body	(json/generate-string	transacao)
			:throw-exceptions	false})
(defn	despesa	[valor]
		(conteudo-como-json	{:valor	valor	:tipo	"despesa"}))
(defn	receita	[valor]
		(conteudo-como-json	{:valor	valor	:tipo	"receita"}))